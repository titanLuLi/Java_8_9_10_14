package org.paumard.chaining.model;

public class Meteo {

	private int temperature;

	public Meteo(int temperature) {
		this.temperature = temperature;
	}

	public int getTemperature() {
		return temperature;
	}
}
