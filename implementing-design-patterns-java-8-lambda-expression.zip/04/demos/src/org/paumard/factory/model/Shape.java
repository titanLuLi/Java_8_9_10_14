package org.paumard.factory.model;

public abstract class Shape {
}
