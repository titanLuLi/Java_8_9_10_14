package org.paumard.factory.model;

public class Square extends Shape {

	@Override
	public String toString() {
		return "Square []";
	}
}
