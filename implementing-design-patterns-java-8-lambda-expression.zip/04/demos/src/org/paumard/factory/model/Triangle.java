package org.paumard.factory.model;

public class Triangle extends Shape {

	@Override
	public String toString() {
		return "Triangle []";
	}
}
