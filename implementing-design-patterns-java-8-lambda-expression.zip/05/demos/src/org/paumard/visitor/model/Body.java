package org.paumard.visitor.model;

public class Body {

	@Override
	public String toString() {
		return "Body []";
	}
}
