package org.paumard.visitor.model;

public class Car {

	@Override
	public String toString() {
		return "Car []";
	}
}
