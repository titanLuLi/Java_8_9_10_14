package org.paumard.visitor.model;

public class Engine {

	@Override
	public String toString() {
		return "Engine []";
	}
}
