module easytext {
  requires java.base;
}
