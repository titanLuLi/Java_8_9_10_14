module easytext.analysis {
   exports javamodularity.easytext.analysis;
}
