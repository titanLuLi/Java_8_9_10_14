module easytext.cli {
   requires easytext.analysis;
}
