module easytext.gui {
   exports javamodularity.easytext.gui to javafx.graphics;

   requires javafx.controls;
   requires easytext.analysis;
}
