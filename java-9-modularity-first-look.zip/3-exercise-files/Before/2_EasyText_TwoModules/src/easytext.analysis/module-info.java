module easytext.analysis {
   
}
