module easytext {

}
