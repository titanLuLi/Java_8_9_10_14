module easytext.gui {
   requires easytext.analysis;
}
