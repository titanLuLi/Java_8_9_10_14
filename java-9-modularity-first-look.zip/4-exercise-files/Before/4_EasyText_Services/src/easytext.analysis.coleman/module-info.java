module easytext.analysis.coleman {

   requires easytext.analysis.api;

}
