module easytext.analysis.kincaid {

   requires easytext.analysis.api;

}
