module easytext.cli {
   requires easytext.analysis.api;

   
}
