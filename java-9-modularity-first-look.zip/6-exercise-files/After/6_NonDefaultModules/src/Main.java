import javax.xml.bind.DatatypeConverter;

public class Main {

    public static void main(String... args) {
        DatatypeConverter.parseBase64Binary("SGVsbG8gd29ybGQh");
    }
}
