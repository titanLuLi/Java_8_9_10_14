module application {
  requires commons.lang;
}
